package my.foodOn.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DeliveryFoodPanel_BottomNavigation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_food_panel__bottom_navigation);
    }
}